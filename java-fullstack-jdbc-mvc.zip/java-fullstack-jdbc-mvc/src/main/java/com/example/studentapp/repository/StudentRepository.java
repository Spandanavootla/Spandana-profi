package com.example.studentapp.repository;

import com.example.studentapp.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentRepository {
    private final JdbcTemplate jdbc;

    public StudentRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private final org.springframework.jdbc.core.RowMapper<Student> mapper =
        (rs, rowNum) -> new Student(
            rs.getInt("id"),
            rs.getString("name"),
            rs.getString("email"),
            rs.getString("branch")
        );

    public List<Student> findAll() {
        return jdbc.query("SELECT id, name, email, branch FROM students ORDER BY id DESC", mapper);
    }

    public Student findById(int id) {
        return jdbc.queryForObject(
            "SELECT id, name, email, branch FROM students WHERE id = ?",
            mapper, id
        );
    }

    public void save(Student s) {
        jdbc.update(
            "INSERT INTO students(name, email, branch) VALUES (?, ?, ?)",
            s.getName(), s.getEmail(), s.getBranch()
        );
    }

    public void update(Student s) {
        jdbc.update(
            "UPDATE students SET name = ?, email = ?, branch = ? WHERE id = ?",
            s.getName(), s.getEmail(), s.getBranch(), s.getId()
        );
    }

    public void delete(int id) {
        jdbc.update("DELETE FROM students WHERE id = ?", id);
    }
}
