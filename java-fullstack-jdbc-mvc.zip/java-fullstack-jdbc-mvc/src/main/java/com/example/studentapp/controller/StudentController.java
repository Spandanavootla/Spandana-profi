package com.example.studentapp.controller;

import com.example.studentapp.model.Student;
import com.example.studentapp.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class StudentController {
    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/students";
    }

    @GetMapping("/students")
    public String students(Model model) {
        model.addAttribute("students", service.getAll());
        return "students";
    }

    @GetMapping("/students/new")
    public String newStudent(Model model) {
        model.addAttribute("student", new Student());
        return "student-form";
    }

    @PostMapping("/students")
    public String save(@Valid @ModelAttribute("student") Student student,
                       BindingResult result) {
        if (result.hasErrors()) return "student-form";
        service.save(student);
        return "redirect:/students";
    }

    @GetMapping("/students/edit/{id}")
    public String edit(@PathVariable int id, Model model) {
        model.addAttribute("student", service.getById(id));
        return "student-edit";
    }

    @PostMapping("/students/update")
    public String update(@Valid @ModelAttribute("student") Student student,
                         BindingResult result) {
        if (result.hasErrors()) return "student-edit";
        service.update(student);
        return "redirect:/students";
    }

    @PostMapping("/students/delete/{id}")
    public String delete(@PathVariable int id) {
        service.delete(id);
        return "redirect:/students";
    }
}
