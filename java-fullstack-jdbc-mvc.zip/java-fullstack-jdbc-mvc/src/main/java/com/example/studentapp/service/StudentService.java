package com.example.studentapp.service;

import com.example.studentapp.model.Student;
import com.example.studentapp.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public List<Student> getAll() { return repository.findAll(); }
    public Student getById(int id) { return repository.findById(id); }
    public void save(Student s) { repository.save(s); }
    public void update(Student s) { repository.update(s); }
    public void delete(int id) { repository.delete(id); }
}
