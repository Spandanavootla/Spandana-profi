# Java Full Stack Student Management Application

A beginner-friendly Java Full Stack project combining:

- HTML/CSS/JavaScript
- Java
- Spring Boot
- MVC architecture
- Spring JDBC / JdbcTemplate
- MySQL
- Spring Security
- Validation
- Maven
- CRUD operations

## Architecture

Browser
  -> Controller (MVC)
  -> Service
  -> Repository
  -> JdbcTemplate
  -> MySQL

Security is handled by Spring Security before protected controller methods are reached.

## Required software

1. JDK 17+
2. MySQL 8+
3. Maven 3.9+ (or use IntelliJ/Eclipse Maven support)
4. Internet access for Maven dependencies

## Database setup

Create the database:

CREATE DATABASE college;

Update `src/main/resources/application.properties`:

spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD

The app creates the required `students`, `users`, and `authorities` tables from SQL initialization.

## Run

From the project folder:

mvn spring-boot:run

Then open:

http://localhost:8080

Login:

Username: admin
Password: admin123

## Important learning points

- `Controller` handles web requests.
- `Service` contains application/business logic.
- `Repository` talks to the database.
- `JdbcTemplate` performs parameterized SQL operations.
- `PreparedStatement` is used internally by Spring JDBC.
- MySQL Connector/J is the JDBC driver.
- Spring Security protects `/students/**`.
- Thymeleaf renders HTML pages on the server.
- JavaScript adds a small browser-side confirmation.

For production, change the demo password and use environment variables/secrets instead of storing credentials in application.properties.
